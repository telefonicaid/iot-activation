#!/usr/bin/python
# config file containing credentials for rds mysql instance
db_username = "admin"
db_password = "xxx"
db_name = "sensorData"
db_endpoint = "xxx.xxx.xxx.rds.amazonaws.com"

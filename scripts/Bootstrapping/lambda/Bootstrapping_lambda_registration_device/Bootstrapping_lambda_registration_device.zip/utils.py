import logging
import boto3
import json

logger = logging.getLogger()
logger.setLevel(logging.INFO) 

status_registered = "requested"
status_confirmed = "ok"

def device_register(event):
    
    global status_registered
    global status_confirmed
    logger.debug(event)
    
    device_id = event["device"]
    logger.info("Registering new device [ %s ]", (device_id))

    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table("Bootstrapping_table_registration")
    response_item  = table.get_item(Key={"device": device_id})
    logger.debug(response_item)

    if "Item" in response_item:
        device_record = response_item['Item']
        logger.debug (device_record)
        
        if device_record["registered"] == status_confirmed:
            logger.warning("The device is already registered [ %s ]", device_id)
            
            device_connections = device_record["connections"] + 1
            table.update_item(Key={"device": device_id}, UpdateExpression="set connections = :c",
                                              ExpressionAttributeValues={':c': device_connections }, ReturnValues="UPDATED_NEW")

        else:
            logger.info("Star to create new device in IoT Core [ %s ]", device_id)
            
            iot = boto3.client('iot')
            response_create_thing = iot.create_thing(thingName=device_id)
            logger.debug(response_create_thing)
            
            response_create_cert = iot.create_keys_and_certificate(setAsActive=True)
            logger.debug(response_create_cert)
            
            logger.debug ("New certificateID")
            logger.debug (response_create_cert["certificateId"])
            
            response_attach_policy = iot.attach_principal_policy(policyName=device_record["policy"], principal=response_create_cert["certificateArn"])
            logger.debug(response_attach_policy)
            response_attach_thing = iot.attach_thing_principal(thingName=device_id, principal=response_create_cert["certificateArn"])
            logger.debug(response_attach_thing)
            
            device_parameters = device_record["parameters"]
            device_topic = json.loads(device_parameters)
            
            iot_data = boto3.client('iot-data')
            response_publish = iot_data.publish(topic="bs/device/"+device_id+"/credentials/certificate", qos=0, payload=response_create_cert["certificatePem"])
            logger.debug(response_publish)
            response_publish = iot_data.publish(topic="bs/device/"+device_id+"/credentials/key", qos=0, payload=response_create_cert["keyPair"]["PrivateKey"])
            logger.debug(response_publish)
            response_publish = iot_data.publish(topic="bs/device/"+device_id+"/parameters/", qos=0, payload=device_parameters)
            logger.debug(response_publish)
            response_publish = iot_data.publish(topic="bs/device/"+device_id+"/parameters/topic", qos=0, payload=device_topic["topic"])
            logger.debug(response_publish)
            
            response = table.update_item(Key={"device": device_id}, UpdateExpression="set registered = :s",
                                              ExpressionAttributeValues={':s': status_registered },ReturnValues="UPDATED_NEW")
            logger.debug(response)
            logger.info("set status %s ", status_registered)
            
            logger.info("New device registered")
                                          
    else:
        logger.error("Unidentified device")


def device_confirm(event):
    
    global status_registered
    global status_confirmed
    logger.debug(event)
    
    device_id = event["device"]
    logger.info("Confirm the registration request [ %s ]", (device_id))
    
    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table("Bootstrapping_table_registration")
    response_item  = table.get_item(Key={"device": device_id})
    logger.debug(response_item)
    
    if "Item" in response_item:
        device_record = response_item['Item']
        logger.debug (device_record)
        
        if device_record["registered"] == status_confirmed:
            logger.warning("The device [ %s ] is already confirmed ", device_id)
            
            device_connections = device_record["connections"] + 1
            table.update_item(Key={"device": device_id}, UpdateExpression="set connections = :c",
                                              ExpressionAttributeValues={':c': device_connections },ReturnValues="UPDATED_NEW")
        else:    
            if device_record["registered"] == status_registered:
            
                logger.info("Star device corfirmation [ %s ]", device_id)
                
                
                response = table.update_item(Key={"device": device_id}, UpdateExpression="set registered = :s",
                                              ExpressionAttributeValues={':s': status_confirmed },ReturnValues="UPDATED_NEW")
                logger.info(response)
                logger.info("set status confirmed  %s ", status_confirmed)
                
            else:
                logger.warning("The device is not registered [ %s ]", device_id)
                
    else:
        logger.error("Unidentified device")
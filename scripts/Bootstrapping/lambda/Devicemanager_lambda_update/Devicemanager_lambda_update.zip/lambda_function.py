from utils import *


def lambda_handler(event, context):
    
    # TODO implement
    logger.debug(context)
    logger.debug(event)
    
    topic_level = event["level"]
    logger.info("Message detected in the topic level [ %s ]", (topic_level))
    
    switcher  = {
        "request" : fw_request,
        "ok":  fw_confirm
    }
    
    func = switcher.get(topic_level, lambda: "Invalid topic level")
    func(event)
    
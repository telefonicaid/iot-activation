import logging
import json
import boto3
import base64

logger = logging.getLogger()
logger.setLevel(logging.INFO) 

def fw_request(event):

    logger.debug(event)
    
    device_id = event["device"]
    device_version = 0
    if "version" in event:
        device_version = event["version"]
        
    logger.info("The device [ %s ] request the firmware version: [ %s ]" % (device_id, str(device_version)))
    
    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table("Bootstrapping_table_registration")
    response_item  = table.get_item(Key={"device": device_id})
    logger.debug(response_item)
    
    if "Item" in response_item:
        
        device_record = response_item['Item']
        logger.debug(device_record)
        
        if device_record["registered"] == "ok":
            logger.info("The device [ %s ] is already registered", (device_id))
            
            device_firmware = device_record['firmware']
            device_version = device_record['version']
            logger.debug(device_firmware)
            logger.debug(device_version)

            response_item_fw = table.get_item(Key={"device": device_firmware })
            logger.debug(response_item_fw)
            
            fw_bucket = response_item_fw['Item']['bucket']
            fw_file = response_item_fw['Item']['file']
            logger.debug(fw_bucket)
            logger.debug(fw_file)
            
            s3 = boto3.client('s3')
            #device_software_file = 'software/' + device_record['software'] + str(device_version_updated) + '.zip'
            #logger.debug(device_software_file)
            data = s3.get_object(Bucket=fw_bucket, Key=fw_file)
            contents = data['Body'].read()
            encode_contents = base64.b64encode(contents)
            logger.debug(encode_contents)
            iot_data = boto3.client('iot-data')
            topic_update="dm/device/"+device_id+"/update/"
            logger.debug(topic_update)
            response_publish = iot_data.publish(topic=topic_update, qos=0, payload=encode_contents)
            
        else:                                      
            logger.warning("The device is not registered")
                                          
    else:
        logger.warning("Unidentified device")

    
def fw_confirm(event):
    
    logger.debug(event)
    
    device_id = event["device"]
    device_version = 0
    if "version" in event:
        device_version = event["version"]
        
    logger.info("The device [ %s ] confirm the firmware version: [ %s ]" % (device_id, device_version))
    
    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table("Bootstrapping_table_registration")
    response_item  = table.get_item(Key={"device": device_id})
    logger.debug(response_item)
    
    if "Item" in response_item:
        
        device_record = response_item['Item']
        logger.debug(device_record)
        
        if device_record["registered"] == "ok":
            table.update_item(Key={"device": device_id}, UpdateExpression="set version = :c",
                                              ExpressionAttributeValues={':c': device_version })
                                              
            logger.info("firmware version [ %s ] update", (device_version))
            
        else:
            logger.warning("The device is not registered")
                                              
    else:
        logger.warning("Unidentified device")
    
    